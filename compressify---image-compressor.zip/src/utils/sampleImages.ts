/**
 * Generates rich, authentic sample JPEG and transparent PNG files
 * so users can immediately test compression without uploading local files.
 */

export async function createSampleJpeg(): Promise<File> {
  const canvas = document.createElement('canvas');
  canvas.width = 1600;
  canvas.height = 1000;
  const ctx = canvas.getContext('2d')!;

  // Dynamic sky & landscape gradient
  const grad = ctx.createLinearGradient(0, 0, 1600, 1000);
  grad.addColorStop(0, '#0f172a');
  grad.addColorStop(0.3, '#1e293b');
  grad.addColorStop(0.6, '#334155');
  grad.addColorStop(1, '#0284c7');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 1600, 1000);

  // Geometric landscape waves with subtle noise
  for (let layer = 0; layer < 6; layer++) {
    ctx.beginPath();
    ctx.moveTo(0, 500 + layer * 70);
    for (let x = 0; x <= 1600; x += 20) {
      const y = 500 + layer * 70 + Math.sin(x * 0.005 + layer) * 80 + Math.cos(x * 0.01) * 30;
      ctx.lineTo(x, y);
    }
    ctx.lineTo(1600, 1000);
    ctx.lineTo(0, 1000);
    ctx.closePath();
    ctx.fillStyle = `rgba(${30 + layer * 25}, ${41 + layer * 20}, ${59 + layer * 30}, ${0.5 + layer * 0.08})`;
    ctx.fill();
  }

  // Golden sun sphere with glow
  const sunGrad = ctx.createRadialGradient(1200, 320, 10, 1200, 320, 220);
  sunGrad.addColorStop(0, '#fbbf24');
  sunGrad.addColorStop(0.4, '#f59e0b');
  sunGrad.addColorStop(0.8, 'rgba(245, 158, 11, 0.2)');
  sunGrad.addColorStop(1, 'rgba(245, 158, 11, 0)');
  ctx.fillStyle = sunGrad;
  ctx.beginPath();
  ctx.arc(1200, 320, 220, 0, Math.PI * 2);
  ctx.fill();

  // Fine texture & detail stars
  for (let i = 0; i < 400; i++) {
    const x = Math.random() * 1600;
    const y = Math.random() * 550;
    const r = Math.random() * 2;
    ctx.fillStyle = `rgba(255, 255, 255, ${Math.random() * 0.8})`;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // Crisp typographic label
  ctx.font = '600 36px "Plus Jakarta Sans", sans-serif';
  ctx.fillStyle = '#f8fafc';
  ctx.fillText('Sample High-Res Landscape', 80, 120);

  ctx.font = '400 20px "JetBrains Mono", monospace';
  ctx.fillStyle = '#94a3b8';
  ctx.fillText('Resolution: 1600 × 1000 · Format: JPEG · Uncompressed Master', 80, 160);

  const blob = await new Promise<Blob>((resolve) => canvas.toBlob((b) => resolve(b!), 'image/jpeg', 0.98));
  return new File([blob], 'sample-landscape-highres.jpg', { type: 'image/jpeg' });
}

export async function createSamplePng(): Promise<File> {
  const canvas = document.createElement('canvas');
  canvas.width = 1200;
  canvas.height = 1200;
  const ctx = canvas.getContext('2d')!;

  // Clear transparent canvas
  ctx.clearRect(0, 0, 1200, 1200);

  // Modern isometric transparent graphic emblem
  const centerX = 600;
  const centerY = 600;

  // Background soft radial aura (with transparent outer edge)
  const aura = ctx.createRadialGradient(centerX, centerY, 80, centerX, centerY, 520);
  aura.addColorStop(0, 'rgba(6, 182, 212, 0.45)');
  aura.addColorStop(0.5, 'rgba(59, 130, 246, 0.25)');
  aura.addColorStop(1, 'rgba(59, 130, 246, 0)');
  ctx.fillStyle = aura;
  ctx.beginPath();
  ctx.arc(centerX, centerY, 520, 0, Math.PI * 2);
  ctx.fill();

  // Interlocking modern geometric rings with transparency
  const colors = [
    'rgba(14, 165, 233, 0.9)',
    'rgba(99, 102, 241, 0.9)',
    'rgba(168, 85, 247, 0.9)',
    'rgba(236, 72, 153, 0.9)',
    'rgba(34, 197, 94, 0.9)',
  ];

  for (let i = 0; i < 5; i++) {
    ctx.save();
    ctx.translate(centerX, centerY);
    ctx.rotate((i * Math.PI) / 2.5);

    ctx.fillStyle = colors[i];
    ctx.beginPath();
    ctx.roundRect(-180, -280, 120, 360, 60);
    ctx.fill();

    // Inner highlight
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.roundRect(-175, -275, 110, 350, 55);
    ctx.stroke();

    ctx.restore();
  }

  // Central core badge
  ctx.fillStyle = '#0f172a';
  ctx.beginPath();
  ctx.arc(centerX, centerY, 150, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = '#38bdf8';
  ctx.lineWidth = 8;
  ctx.stroke();

  // Icon symbol in center
  ctx.font = '700 80px "JetBrains Mono", monospace';
  ctx.fillStyle = '#38bdf8';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('PNG', centerX, centerY);

  // Subtitle
  ctx.font = '500 22px "Plus Jakarta Sans", sans-serif';
  ctx.fillStyle = '#cbd5e1';
  ctx.fillText('Transparent Master (1200×1200)', centerX, centerY + 240);

  const blob = await new Promise<Blob>((resolve) => canvas.toBlob((b) => resolve(b!), 'image/png'));
  return new File([blob], 'sample-vector-badge.png', { type: 'image/png' });
}
