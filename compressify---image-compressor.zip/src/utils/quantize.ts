/**
 * Fast Color Quantization with Floyd-Steinberg Dithering
 * Reduces image color palette (e.g. 16-256 colors) to achieve dramatic PNG compression ratios
 * while preserving transparency and visual fidelity.
 */

interface RGBColor {
  r: number;
  g: number;
  b: number;
}

interface ColorBox {
  colors: RGBColor[];
  rMin: number;
  rMax: number;
  gMin: number;
  gMax: number;
  bMin: number;
  bMax: number;
  volume: number;
}

function createBox(colors: RGBColor[]): ColorBox {
  let rMin = 255, rMax = 0;
  let gMin = 255, gMax = 0;
  let bMin = 255, bMax = 0;

  for (let i = 0; i < colors.length; i++) {
    const c = colors[i];
    if (c.r < rMin) rMin = c.r;
    if (c.r > rMax) rMax = c.r;
    if (c.g < gMin) gMin = c.g;
    if (c.g > gMax) gMax = c.g;
    if (c.b < bMin) bMin = c.b;
    if (c.b > bMax) bMax = c.b;
  }

  const rDiff = rMax - rMin;
  const gDiff = gMax - gMin;
  const bDiff = bMax - bMin;
  const volume = (rDiff + 1) * (gDiff + 1) * (bDiff + 1);

  return { colors, rMin, rMax, gMin, gMax, bMin, bMax, volume };
}

function findLongestAxis(box: ColorBox): 'r' | 'g' | 'b' {
  const rDiff = box.rMax - box.rMin;
  const gDiff = box.gMax - box.gMin;
  const bDiff = box.bMax - box.bMin;

  if (rDiff >= gDiff && rDiff >= bDiff) return 'r';
  if (gDiff >= rDiff && gDiff >= bDiff) return 'g';
  return 'b';
}

function splitBox(box: ColorBox): [ColorBox, ColorBox] {
  if (box.colors.length <= 1) return [box, box];

  const axis = findLongestAxis(box);
  box.colors.sort((a, b) => a[axis] - b[axis]);

  const medianIndex = Math.floor(box.colors.length / 2);
  const part1 = box.colors.slice(0, medianIndex);
  const part2 = box.colors.slice(medianIndex);

  return [createBox(part1), createBox(part2)];
}

function medianCut(colors: RGBColor[], maxColors: number): RGBColor[] {
  if (colors.length === 0) return [{ r: 0, g: 0, b: 0 }];
  if (colors.length <= maxColors) return colors;

  const boxes: ColorBox[] = [createBox(colors)];

  while (boxes.length < maxColors) {
    // Find box with highest volume that has more than 1 color
    let bestIndex = -1;
    let maxVolume = -1;

    for (let i = 0; i < boxes.length; i++) {
      if (boxes[i].colors.length > 1 && boxes[i].volume > maxVolume) {
        maxVolume = boxes[i].volume;
        bestIndex = i;
      }
    }

    if (bestIndex === -1) break;

    const [box1, box2] = splitBox(boxes[bestIndex]);
    boxes.splice(bestIndex, 1, box1, box2);
  }

  // Calculate average color for each box
  return boxes.map((box) => {
    let rSum = 0;
    let gSum = 0;
    let bSum = 0;
    const len = box.colors.length;

    for (let i = 0; i < len; i++) {
      rSum += box.colors[i].r;
      gSum += box.colors[i].g;
      bSum += box.colors[i].b;
    }

    return {
      r: Math.round(rSum / len),
      g: Math.round(gSum / len),
      b: Math.round(bSum / len),
    };
  });
}

function findNearestColor(color: RGBColor, palette: RGBColor[]): RGBColor {
  let minDistance = Infinity;
  let nearest = palette[0];

  for (let i = 0; i < palette.length; i++) {
    const p = palette[i];
    // Weighted Euclidean distance (redmean color distance approximation)
    const rMean = (color.r + p.r) / 2;
    const dr = color.r - p.r;
    const dg = color.g - p.g;
    const db = color.b - p.b;

    const dist =
      (2 + rMean / 256) * dr * dr +
      4 * dg * dg +
      (2 + (255 - rMean) / 256) * db * db;

    if (dist < minDistance) {
      minDistance = dist;
      nearest = p;
      if (dist === 0) break;
    }
  }

  return nearest;
}

/**
 * Quantize ImageData to a specific palette size (16-256) with optional dithering.
 * Directly modifies ImageData in-place.
 */
export function quantizeImageData(
  imageData: ImageData,
  colorCount: number,
  useDithering: boolean = true
): void {
  const data = imageData.data;
  const width = imageData.width;
  const height = imageData.height;
  const totalPixels = width * height;

  if (colorCount >= 256 && !useDithering) {
    // Already highest or lossless
    return;
  }

  // 1. Sample pixels to build the palette (downsample step for high speed on large images)
  const sampleStep = Math.max(1, Math.floor(totalPixels / 20000));
  const sampleColors: RGBColor[] = [];

  for (let i = 0; i < data.length; i += 4 * sampleStep) {
    const a = data[i + 3];
    if (a > 32) {
      // Ignore almost fully transparent pixels in palette building
      sampleColors.push({
        r: data[i],
        g: data[i + 1],
        b: data[i + 2],
      });
    }
  }

  if (sampleColors.length === 0) return;

  // 2. Generate palette
  const palette = medianCut(sampleColors, Math.min(colorCount, 256));

  // 3. Fast mapping with color caching
  const colorCache = new Map<number, RGBColor>();
  const getNearest = (r: number, g: number, b: number): RGBColor => {
    // Quantize 5-bit key for fast cache lookup
    const key = ((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3);
    const cached = colorCache.get(key);
    if (cached) return cached;
    const nearest = findNearestColor({ r, g, b }, palette);
    colorCache.set(key, nearest);
    return nearest;
  };

  if (!useDithering) {
    for (let i = 0; i < data.length; i += 4) {
      const a = data[i + 3];
      if (a <= 16) {
        data[i + 3] = 0; // fully transparent
        continue;
      }
      const nearest = getNearest(data[i], data[i + 1], data[i + 2]);
      data[i] = nearest.r;
      data[i + 1] = nearest.g;
      data[i + 2] = nearest.b;
    }
    return;
  }

  // 4. Floyd-Steinberg error diffusion dithering
  // Pre-allocate error buffers (2 rows of errors for RGB)
  const curErrorR = new Float32Array(width + 2);
  const curErrorG = new Float32Array(width + 2);
  const curErrorB = new Float32Array(width + 2);
  const nextErrorR = new Float32Array(width + 2);
  const nextErrorG = new Float32Array(width + 2);
  const nextErrorB = new Float32Array(width + 2);

  for (let y = 0; y < height; y++) {
    // Reset next row error
    nextErrorR.fill(0);
    nextErrorG.fill(0);
    nextErrorB.fill(0);

    for (let x = 0; x < width; x++) {
      const idx = (y * width + x) * 4;
      const alpha = data[idx + 3];

      if (alpha <= 16) {
        data[idx + 3] = 0;
        continue;
      }

      // Pixel with distributed error from neighbors
      const offset = x + 1;
      const oldR = Math.min(255, Math.max(0, data[idx] + curErrorR[offset]));
      const oldG = Math.min(255, Math.max(0, data[idx + 1] + curErrorG[offset]));
      const oldB = Math.min(255, Math.max(0, data[idx + 2] + curErrorB[offset]));

      const nearest = getNearest(Math.round(oldR), Math.round(oldG), Math.round(oldB));

      data[idx] = nearest.r;
      data[idx + 1] = nearest.g;
      data[idx + 2] = nearest.b;

      // Quantization error
      const errR = oldR - nearest.r;
      const errG = oldG - nearest.g;
      const errB = oldB - nearest.b;

      // Floyd-Steinberg distribution:
      // (x+1, y)   : 7/16
      // (x-1, y+1) : 3/16
      // (x,   y+1) : 5/16
      // (x+1, y+1) : 1/16
      curErrorR[offset + 1] += (errR * 7) / 16;
      curErrorG[offset + 1] += (errG * 7) / 16;
      curErrorB[offset + 1] += (errB * 7) / 16;

      nextErrorR[offset - 1] += (errR * 3) / 16;
      nextErrorG[offset - 1] += (errG * 3) / 16;
      nextErrorB[offset - 1] += (errB * 3) / 16;

      nextErrorR[offset] += (errR * 5) / 16;
      nextErrorG[offset] += (errG * 5) / 16;
      nextErrorB[offset] += (errB * 5) / 16;

      nextErrorR[offset + 1] += (errR * 1) / 16;
      nextErrorG[offset + 1] += (errG * 1) / 16;
      nextErrorB[offset + 1] += (errB * 1) / 16;
    }

    // Move next row errors to current row
    curErrorR.set(nextErrorR);
    curErrorG.set(nextErrorG);
    curErrorB.set(nextErrorB);
  }
}
