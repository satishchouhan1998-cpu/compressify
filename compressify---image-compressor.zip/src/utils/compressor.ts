import JSZip from 'jszip';
import { GlobalSettings, ImageFileItem, ImageFormat } from '../types/compressor';
import { quantizeImageData } from './quantize';

/**
 * Format bytes into human-readable string (e.g. 1.24 MB, 450 KB)
 */
export function formatBytes(bytes: number, decimals: number = 1): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(Math.abs(bytes)) / Math.log(k));
  const idx = Math.min(i, sizes.length - 1);
  return `${parseFloat((bytes / Math.pow(k, idx)).toFixed(dm))} ${sizes[idx]}`;
}

/**
 * Load File into an HTMLImageElement
 */
export function loadImageFromFile(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = (err) => {
      URL.revokeObjectURL(url);
      reject(new Error('Failed to load image file.'));
    };
    img.src = url;
  });
}

/**
 * Compute target dimensions based on settings
 */
export function computeDimensions(
  originalWidth: number,
  originalHeight: number,
  settings: GlobalSettings
): { width: number; height: number } {
  if (settings.resizeMode === 'scale') {
    const scale = Math.max(1, Math.min(100, settings.scalePercent)) / 100;
    return {
      width: Math.max(1, Math.round(originalWidth * scale)),
      height: Math.max(1, Math.round(originalHeight * scale)),
    };
  }

  if (settings.resizeMode === 'dimensions') {
    let targetW = settings.maxWidth && settings.maxWidth > 0 ? settings.maxWidth : originalWidth;
    let targetH = settings.maxHeight && settings.maxHeight > 0 ? settings.maxHeight : originalHeight;

    if (settings.maintainAspectRatio) {
      const ratio = originalWidth / originalHeight;
      if (originalWidth > originalHeight) {
        if (targetW < originalWidth) {
          targetH = Math.round(targetW / ratio);
        }
      } else {
        if (targetH < originalHeight) {
          targetW = Math.round(targetH * ratio);
        }
      }
    }

    return {
      width: Math.max(1, targetW),
      height: Math.max(1, targetH),
    };
  }

  return { width: originalWidth, height: originalHeight };
}

/**
 * Determines output mime type
 */
export function getTargetMimeType(
  originalFormat: ImageFormat,
  outputChoice: GlobalSettings['outputFormat']
): ImageFormat {
  if (outputChoice === 'original') {
    return originalFormat;
  }
  return outputChoice;
}

/**
 * Map quality (1-100) to effective PNG palette color count
 */
export function mapPngQualityToColors(quality: number): number {
  if (quality >= 98) return 256;
  if (quality >= 80) return Math.round(128 + ((quality - 80) / 20) * 128); // 128-256
  if (quality >= 50) return Math.round(64 + ((quality - 50) / 30) * 64);   // 64-128
  if (quality >= 25) return Math.round(32 + ((quality - 25) / 25) * 32);   // 32-64
  return Math.max(8, Math.round(8 + (quality / 25) * 24));                  // 8-32
}

/**
 * Compress a single image item given active settings
 */
export async function compressImage(
  item: ImageFileItem,
  effectiveSettings: GlobalSettings
): Promise<{
  blob: Blob;
  url: string;
  size: number;
  width: number;
  height: number;
  format: ImageFormat;
  savingsBytes: number;
  savingsPercent: number;
}> {
  const img = await loadImageFromFile(item.file);
  const { width: targetWidth, height: targetHeight } = computeDimensions(
    img.naturalWidth,
    img.naturalHeight,
    effectiveSettings
  );

  const canvas = document.createElement('canvas');
  canvas.width = targetWidth;
  canvas.height = targetHeight;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });

  if (!ctx) {
    throw new Error('Canvas 2D context could not be initialized.');
  }

  const targetFormat = getTargetMimeType(item.originalFormat, effectiveSettings.outputFormat);

  // If output is JPEG, canvas does not have alpha channel, fill with crisp white to prevent black backgrounds
  if (targetFormat === 'image/jpeg') {
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, targetWidth, targetHeight);
  }

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(img, 0, 0, targetWidth, targetHeight);

  // Perform PNG color quantization if target is PNG
  if (targetFormat === 'image/png') {
    const effectiveColors = effectiveSettings.pngColors || mapPngQualityToColors(effectiveSettings.pngQuality);
    
    // Only quantize if less than 256 colors or quality < 99
    if (effectiveColors < 256 || effectiveSettings.pngQuality < 98) {
      const imageData = ctx.getImageData(0, 0, targetWidth, targetHeight);
      quantizeImageData(imageData, effectiveColors, effectiveSettings.pngDither);
      ctx.putImageData(imageData, 0, 0);
    }
  }

  // Convert canvas to Blob
  const blob = await new Promise<Blob>((resolve, reject) => {
    let encoderQuality: number | undefined = undefined;

    if (targetFormat === 'image/jpeg' || targetFormat === 'image/webp') {
      encoderQuality = Math.max(0.01, Math.min(1.0, effectiveSettings.jpegQuality / 100));
    }

    canvas.toBlob(
      (b) => {
        if (b) resolve(b);
        else reject(new Error('Failed to encode image to blob.'));
      },
      targetFormat,
      encoderQuality
    );
  });

  const compressedSize = blob.size;
  const originalSize = item.originalSize;
  const savingsBytes = originalSize - compressedSize;
  const savingsPercent = originalSize > 0 ? (savingsBytes / originalSize) * 100 : 0;
  const compressedUrl = URL.createObjectURL(blob);

  return {
    blob,
    url: compressedUrl,
    size: compressedSize,
    width: targetWidth,
    height: targetHeight,
    format: targetFormat,
    savingsBytes,
    savingsPercent,
  };
}

/**
 * Triggers a download of a Blob
 */
export function downloadFile(blob: Blob, filename: string): void {
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(link.href), 1000);
}

/**
 * Generates an output filename based on original name and target format
 */
export function getOutputFilename(originalName: string, targetFormat: ImageFormat): string {
  const lastDot = originalName.lastIndexOf('.');
  const baseName = lastDot !== -1 ? originalName.substring(0, lastDot) : originalName;
  
  let ext = 'jpg';
  if (targetFormat === 'image/png') ext = 'png';
  if (targetFormat === 'image/webp') ext = 'webp';

  return `${baseName}-compressed.${ext}`;
}

/**
 * Batch download all completed items as a single ZIP archive
 */
export async function downloadAllAsZip(
  items: ImageFileItem[],
  onProgress?: (progress: number) => void
): Promise<void> {
  const zip = new JSZip();
  const folder = zip.folder('compressed_images');

  const readyItems = items.filter((item) => item.status === 'done' && item.compressedBlob);

  if (readyItems.length === 0) return;

  for (const item of readyItems) {
    if (item.compressedBlob) {
      const filename = getOutputFilename(item.name, item.compressedFormat);
      folder?.file(filename, item.compressedBlob);
    }
  }

  const content = await zip.generateAsync(
    { type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 6 } },
    (metadata) => {
      if (onProgress) {
        onProgress(metadata.percent);
      }
    }
  );

  downloadFile(content, 'compressify-images.zip');
}
