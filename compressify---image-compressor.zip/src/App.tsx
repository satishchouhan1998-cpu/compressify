/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useCallback, useRef, useEffect } from 'react';
import { Header } from './components/Header';
import { DropZone } from './components/DropZone';
import { SettingsPanel } from './components/SettingsPanel';
import { ImageCard } from './components/ImageCard';
import { StatsSummary } from './components/StatsSummary';
import { CompareModal } from './components/CompareModal';
import { TechPrivacySection } from './components/TechPrivacySection';
import {
  GlobalSettings,
  ImageFileItem,
  ImageFormat,
  CompressionPreset,
} from './types/compressor';
import {
  compressImage,
  downloadAllAsZip,
  loadImageFromFile,
} from './utils/compressor';
import { ArrowDown, Layers, Sparkles, SlidersHorizontal, Image as ImageIcon } from 'lucide-react';

const DEFAULT_SETTINGS: GlobalSettings = {
  jpegQuality: 80,
  pngQuality: 80,
  pngColors: 128,
  pngDither: true,
  outputFormat: 'original',
  resizeMode: 'none',
  scalePercent: 100,
  maintainAspectRatio: true,
  preset: 'balanced',
};

export default function App() {
  const [items, setItems] = useState<ImageFileItem[]>([]);
  const [settings, setSettings] = useState<GlobalSettings>(DEFAULT_SETTINGS);
  const [activeCompareItem, setActiveCompareItem] = useState<ImageFileItem | null>(null);
  const [isZipping, setIsZipping] = useState(false);
  const [zipProgress, setZipProgress] = useState(0);

  // Ref to trigger file input browse from Header
  const dropzoneRef = useRef<HTMLDivElement>(null);

  // Helper to detect format
  const getFormat = (file: File): ImageFormat => {
    if (file.type === 'image/png') return 'image/png';
    if (file.type === 'image/webp') return 'image/webp';
    return 'image/jpeg';
  };

  // Recompress all items or a specific item
  const processItemCompression = useCallback(
    async (item: ImageFileItem, effectiveSettings: GlobalSettings) => {
      try {
        const result = await compressImage(item, effectiveSettings);
        setItems((prev) =>
          prev.map((i) =>
            i.id === item.id
              ? {
                  ...i,
                  compressedBlob: result.blob,
                  compressedUrl: result.url,
                  compressedSize: result.size,
                  compressedWidth: result.width,
                  compressedHeight: result.height,
                  compressedFormat: result.format,
                  savingsBytes: result.savingsBytes,
                  savingsPercent: result.savingsPercent,
                  status: 'done',
                }
              : i
          )
        );
      } catch (err: any) {
        console.error('Compression failure for:', item.name, err);
        setItems((prev) =>
          prev.map((i) =>
            i.id === item.id
              ? {
                  ...i,
                  status: 'error',
                  errorMessage: err?.message || 'Failed to compress image.',
                }
              : i
          )
        );
      }
    },
    []
  );

  // Keep ref of latest settings for async file processing
  const settingsRef = useRef(settings);
  useEffect(() => {
    settingsRef.current = settings;
  }, [settings]);

  // Handle incoming files from Dropzone / Paste
  const handleFilesSelected = useCallback(async (newFiles: File[]) => {
    const newItems: ImageFileItem[] = [];

    for (const file of newFiles) {
      const id = `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
      const originalFormat = getFormat(file);
      const originalUrl = URL.createObjectURL(file);

      // Measure dimensions
      let width = 0;
      let height = 0;
      try {
        const img = await loadImageFromFile(file);
        width = img.naturalWidth;
        height = img.naturalHeight;
      } catch {
        // Fallback default if decode fails
        width = 800;
        height = 600;
      }

      const item: ImageFileItem = {
        id,
        file,
        name: file.name,
        originalSize: file.size,
        originalWidth: width,
        originalHeight: height,
        originalFormat,
        originalUrl,
        compressedBlob: null,
        compressedUrl: null,
        compressedSize: 0,
        compressedWidth: width,
        compressedHeight: height,
        compressedFormat: originalFormat,
        savingsPercent: 0,
        savingsBytes: 0,
        status: 'compressing',
      };

      newItems.push(item);
    }

    setItems((prev) => [...newItems, ...prev]);

    // Trigger compression for newly added items
    for (const item of newItems) {
      processItemCompression(item, settingsRef.current);
    }
  }, [processItemCompression]);

  // Recompress all items when global settings change
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);

  const handleSettingsChange = (updated: Partial<GlobalSettings>) => {
    const newSettings = { ...settings, ...updated };
    setSettings(newSettings);

    if (items.length === 0) return;

    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    debounceTimerRef.current = setTimeout(() => {
      // Mark all items without custom settings as compressing
      setItems((prev) =>
        prev.map((i) => (i.customSettings ? i : { ...i, status: 'compressing' }))
      );

      items.forEach((item) => {
        if (!item.customSettings) {
          processItemCompression(item, newSettings);
        }
      });
    }, 250);
  };

  // Presets mapping
  const handleApplyPreset = (preset: CompressionPreset) => {
    let newSettings: GlobalSettings;

    switch (preset) {
      case 'max_compression':
        newSettings = {
          ...settings,
          jpegQuality: 60,
          pngQuality: 50,
          pngColors: 32,
          pngDither: true,
          resizeMode: 'scale',
          scalePercent: 80,
          preset: 'max_compression',
        };
        break;
      case 'high_quality':
        newSettings = {
          ...settings,
          jpegQuality: 92,
          pngQuality: 95,
          pngColors: 256,
          pngDither: false,
          resizeMode: 'none',
          scalePercent: 100,
          preset: 'high_quality',
        };
        break;
      case 'balanced':
        newSettings = {
          ...settings,
          jpegQuality: 80,
          pngQuality: 80,
          pngColors: 128,
          pngDither: true,
          resizeMode: 'none',
          scalePercent: 100,
          preset: 'balanced',
        };
        break;
      default:
        newSettings = { ...settings, preset: 'custom' };
    }

    handleSettingsChange(newSettings);
  };

  // Per-item tune change
  const handleTuneItem = (id: string, customSettings: Partial<GlobalSettings>) => {
    const item = items.find((i) => i.id === id);
    if (!item) return;

    const mergedSettings: GlobalSettings = {
      ...settings,
      ...(item.customSettings || {}),
      ...customSettings,
    };

    setItems((prev) =>
      prev.map((i) =>
        i.id === id
          ? {
              ...i,
              customSettings: { ...(i.customSettings || {}), ...customSettings },
              status: 'compressing',
            }
          : i
      )
    );

    processItemCompression(item, mergedSettings);
  };

  // Remove individual item
  const handleRemoveItem = (id: string) => {
    setItems((prev) => {
      const item = prev.find((i) => i.id === id);
      if (item) {
        if (item.originalUrl) URL.revokeObjectURL(item.originalUrl);
        if (item.compressedUrl) URL.revokeObjectURL(item.compressedUrl);
      }
      return prev.filter((i) => i.id !== id);
    });
  };

  // Clear all
  const handleClearAll = () => {
    items.forEach((item) => {
      if (item.originalUrl) URL.revokeObjectURL(item.originalUrl);
      if (item.compressedUrl) URL.revokeObjectURL(item.compressedUrl);
    });
    setItems([]);
  };

  // Download all as ZIP
  const handleDownloadAllZip = async () => {
    if (items.length === 0 || isZipping) return;
    setIsZipping(true);
    setZipProgress(0);

    try {
      await downloadAllAsZip(items, (progress) => {
        setZipProgress(progress);
      });
    } catch (err) {
      console.error('Failed to generate ZIP archive:', err);
    } finally {
      setIsZipping(false);
    }
  };

  // Update item from comparison modal
  const handleUpdateItemFromModal = (updatedItem: ImageFileItem) => {
    setItems((prev) => prev.map((i) => (i.id === updatedItem.id ? updatedItem : i)));
    setActiveCompareItem(updatedItem);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Bar adhering to Top Bar Contract */}
      <Header
        items={items}
        onOpenUpload={() => dropzoneRef.current?.scrollIntoView({ behavior: 'smooth' })}
        onClearAll={handleClearAll}
        onDownloadAll={handleDownloadAllZip}
        isZipping={isZipping}
        zipProgress={zipProgress}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Hero Section */}
        <section id="compressor" className="text-center max-w-3xl mx-auto pt-2 pb-2">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white text-balance leading-tight">
            Free High-Performance Image Compression for{' '}
            <span className="bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 bg-clip-text text-transparent">
              JPEG & PNG
            </span>
          </h1>
          <p className="mt-3 text-sm sm:text-base text-slate-400 max-w-2xl mx-auto leading-relaxed">
            Shrink file sizes by up to 80% without noticeable quality loss. Private, in-browser
            processing with adjustable quantization, instant side-by-side comparison, and batch ZIP export.
          </p>
        </section>

        {/* Drag and Drop Zone */}
        <div ref={dropzoneRef}>
          <DropZone onFilesSelected={handleFilesSelected} />
        </div>

        {/* Global Settings & Presets */}
        <SettingsPanel
          settings={settings}
          onChange={handleSettingsChange}
          onApplyPreset={handleApplyPreset}
        />

        {/* Overall Stats Summary */}
        {items.length > 0 && <StatsSummary items={items} />}

        {/* Batch Queue & Image Cards */}
        {items.length > 0 && (
          <section id="queue" className="space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyan-400" />
                <h2 className="text-base font-semibold text-white">
                  Batch Queue ({items.length} {items.length === 1 ? 'file' : 'files'})
                </h2>
              </div>
              <span className="text-xs text-slate-400">
                Click any image to inspect Before vs After
              </span>
            </div>

            <div className="space-y-3">
              {items.map((item) => (
                <ImageCard
                  key={item.id}
                  item={item}
                  globalSettings={settings}
                  onRemove={handleRemoveItem}
                  onOpenCompare={(i) => setActiveCompareItem(i)}
                  onTuneItem={handleTuneItem}
                />
              ))}
            </div>
          </section>
        )}

        {/* Technical Architecture & Privacy */}
        <TechPrivacySection />
      </main>

      {/* Interactive Before / After Modal */}
      {activeCompareItem && (
        <CompareModal
          item={activeCompareItem}
          globalSettings={settings}
          onClose={() => setActiveCompareItem(null)}
          onUpdateItem={handleUpdateItemFromModal}
        />
      )}

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 mt-16 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>© {new Date().getFullYear()} Compressify. Fast, in-memory browser image optimization.</p>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Supports JPEG & PNG</span>
            <span aria-hidden="true">·</span>
            <span>100% Client-Side</span>
            <span aria-hidden="true">·</span>
            <span>Zero Server Uploads</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
