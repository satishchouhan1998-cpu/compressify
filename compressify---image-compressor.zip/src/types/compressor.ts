export type ImageFormat = 'image/jpeg' | 'image/png' | 'image/webp';

export type OutputFormatChoice = 'original' | 'image/jpeg' | 'image/png' | 'image/webp';

export type CompressionPreset = 'balanced' | 'max_compression' | 'high_quality' | 'custom';

export interface GlobalSettings {
  jpegQuality: number; // 1 to 100
  pngQuality: number; // 1 to 100 (maps to color quantization / colors)
  pngColors: number; // 16, 32, 64, 128, 256
  pngDither: boolean;
  outputFormat: OutputFormatChoice;
  resizeMode: 'none' | 'scale' | 'dimensions';
  scalePercent: number; // 10 to 100
  maxWidth?: number;
  maxHeight?: number;
  maintainAspectRatio: boolean;
  preset: CompressionPreset;
}

export interface ImageFileItem {
  id: string;
  file: File;
  name: string;
  originalSize: number;
  originalWidth: number;
  originalHeight: number;
  originalFormat: ImageFormat;
  originalUrl: string;

  // Custom per-image override (optional)
  customSettings?: Partial<GlobalSettings>;

  // Compressed result
  compressedBlob: Blob | null;
  compressedUrl: string | null;
  compressedSize: number;
  compressedWidth: number;
  compressedHeight: number;
  compressedFormat: ImageFormat;
  savingsPercent: number;
  savingsBytes: number;

  status: 'idle' | 'compressing' | 'done' | 'error';
  errorMessage?: string;
}
