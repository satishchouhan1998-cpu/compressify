import React from 'react';
import { Sliders, Sparkles, Image as ImageIcon, Layers, RefreshCw, Eye } from 'lucide-react';
import { CompressionPreset, GlobalSettings, OutputFormatChoice } from '../types/compressor';

interface SettingsPanelProps {
  settings: GlobalSettings;
  onChange: (updated: Partial<GlobalSettings>) => void;
  onApplyPreset: (preset: CompressionPreset) => void;
  isApplying?: boolean;
}

export const SettingsPanel: React.FC<SettingsPanelProps> = ({
  settings,
  onChange,
  onApplyPreset,
  isApplying,
}) => {
  return (
    <div id="presets" className="border border-slate-800 bg-slate-900/70 rounded-2xl p-5 sm:p-6 backdrop-blur-md">
      {/* Header and Preset buttons */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <h2 className="text-base font-semibold text-white tracking-tight">
              Compression Settings
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Fine-tune JPEG quality, PNG palette quantization, and output geometry.
          </p>
        </div>

        {/* Preset Selector */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-950 border border-slate-800 rounded-xl overflow-x-auto">
          <button
            type="button"
            onClick={() => onApplyPreset('balanced')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
              settings.preset === 'balanced'
                ? 'bg-slate-800 text-cyan-300 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Balanced
          </button>

          <button
            type="button"
            onClick={() => onApplyPreset('max_compression')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
              settings.preset === 'max_compression'
                ? 'bg-slate-800 text-cyan-300 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Max Compression
          </button>

          <button
            type="button"
            onClick={() => onApplyPreset('high_quality')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
              settings.preset === 'high_quality'
                ? 'bg-slate-800 text-cyan-300 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            High Quality
          </button>

          <button
            type="button"
            onClick={() => onApplyPreset('custom')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
              settings.preset === 'custom'
                ? 'bg-slate-800 text-cyan-300 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Custom
          </button>
        </div>
      </div>

      {/* Grid of Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pt-5">
        {/* Column 1: JPEG Quality & Output Format */}
        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between text-xs mb-2">
              <label htmlFor="jpeg-quality" className="font-semibold text-slate-200 flex items-center gap-1.5">
                <span>JPEG Quality</span>
                <span className="text-[10px] text-slate-500 font-normal">DCT Quantization</span>
              </label>
              <span className="font-mono tabular-nums text-cyan-400 font-semibold">
                {settings.jpegQuality}%
              </span>
            </div>
            <input
              id="jpeg-quality"
              type="range"
              min="5"
              max="100"
              step="1"
              value={settings.jpegQuality}
              onChange={(e) => {
                onChange({
                  jpegQuality: Number(e.target.value),
                  preset: 'custom',
                });
              }}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
            />
            <div className="flex justify-between text-[11px] text-slate-500 mt-1 font-mono">
              <span>Small file (10%)</span>
              <span>Default (80%)</span>
              <span>Crisp (100%)</span>
            </div>
          </div>

          <div>
            <label htmlFor="output-format" className="block text-xs font-semibold text-slate-200 mb-2">
              Output Format
            </label>
            <select
              id="output-format"
              value={settings.outputFormat}
              onChange={(e) =>
                onChange({
                  outputFormat: e.target.value as OutputFormatChoice,
                  preset: 'custom',
                })
              }
              className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-cyan-500 transition-colors"
            >
              <option value="original">Keep Original Format</option>
              <option value="image/jpeg">Convert All to JPEG (.jpg)</option>
              <option value="image/png">Convert All to PNG (.png)</option>
              <option value="image/webp">Convert All to WebP (.webp)</option>
            </select>
          </div>
        </div>

        {/* Column 2: PNG Color Quantization */}
        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between text-xs mb-2">
              <label htmlFor="png-palette" className="font-semibold text-slate-200 flex items-center gap-1.5">
                <span>PNG Palette Quantization</span>
                <span className="text-[10px] text-slate-500 font-normal">Color reduction</span>
              </label>
              <span className="font-mono tabular-nums text-cyan-400 font-semibold">
                {settings.pngColors >= 256 ? '256 Colors (High)' : `${settings.pngColors} Colors`}
              </span>
            </div>
            <select
              id="png-palette"
              value={settings.pngColors}
              onChange={(e) =>
                onChange({
                  pngColors: Number(e.target.value),
                  preset: 'custom',
                })
              }
              className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-cyan-500 transition-colors"
            >
              <option value="16">16 Colors (Maximum Compression, ~70% smaller)</option>
              <option value="32">32 Colors (Aggressive Compression)</option>
              <option value="64">64 Colors (Solid Compression)</option>
              <option value="128">128 Colors (Balanced Fidelity)</option>
              <option value="256">256 Colors (High Quality Palette)</option>
            </select>
          </div>

          <div className="flex items-center justify-between pt-1">
            <div>
              <span className="text-xs font-medium text-slate-200 block">Floyd-Steinberg Dithering</span>
              <span className="text-[11px] text-slate-500 block">Smoothes color banding on gradients</span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.pngDither}
                onChange={(e) =>
                  onChange({
                    pngDither: e.target.checked,
                    preset: 'custom',
                  })
                }
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-cyan-500"></div>
            </label>
          </div>
        </div>

        {/* Column 3: Dimension Scaling */}
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-200 mb-2">
              Resize Dimensions
            </label>
            <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-950 border border-slate-800 rounded-lg">
              <button
                type="button"
                onClick={() => onChange({ resizeMode: 'none', preset: 'custom' })}
                className={`py-1 text-xs font-medium rounded transition-colors ${
                  settings.resizeMode === 'none'
                    ? 'bg-slate-800 text-white font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                100%
              </button>
              <button
                type="button"
                onClick={() =>
                  onChange({ resizeMode: 'scale', scalePercent: 75, preset: 'custom' })
                }
                className={`py-1 text-xs font-medium rounded transition-colors ${
                  settings.resizeMode === 'scale' && settings.scalePercent === 75
                    ? 'bg-slate-800 text-white font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                75%
              </button>
              <button
                type="button"
                onClick={() =>
                  onChange({ resizeMode: 'scale', scalePercent: 50, preset: 'custom' })
                }
                className={`py-1 text-xs font-medium rounded transition-colors ${
                  settings.resizeMode === 'scale' && settings.scalePercent === 50
                    ? 'bg-slate-800 text-white font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                50%
              </button>
            </div>
          </div>

          {settings.resizeMode === 'scale' && (
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-slate-400">Scale factor</span>
                <span className="font-mono tabular-nums text-cyan-400">{settings.scalePercent}%</span>
              </div>
              <input
                type="range"
                min="20"
                max="100"
                step="5"
                value={settings.scalePercent}
                onChange={(e) =>
                  onChange({
                    scalePercent: Number(e.target.value),
                    preset: 'custom',
                  })
                }
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
            </div>
          )}

          <div className="text-[11px] text-slate-500 flex items-center gap-1.5 pt-1">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
            <span>Metadata & EXIF are cleanly stripped for privacy</span>
          </div>
        </div>
      </div>
    </div>
  );
};
