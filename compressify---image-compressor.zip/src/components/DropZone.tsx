import React, { useRef, useState, useEffect } from 'react';
import { UploadCloud, Image as ImageIcon, Zap, FileCheck2, ArrowUpRight } from 'lucide-react';
import { createSampleJpeg, createSamplePng } from '../utils/sampleImages';

interface DropZoneProps {
  onFilesSelected: (files: File[]) => void;
  isProcessing?: boolean;
}

export const DropZone: React.FC<DropZoneProps> = ({ onFilesSelected, isProcessing }) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [isLoadingSample, setIsLoadingSample] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Global paste handler to support Ctrl+V / Cmd+V screenshots
  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;

      const pastedFiles: File[] = [];
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.startsWith('image/')) {
          const file = items[i].getAsFile();
          if (file) pastedFiles.push(file);
        }
      }

      if (pastedFiles.length > 0) {
        onFilesSelected(pastedFiles);
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [onFilesSelected]);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const filesArray = Array.from(e.dataTransfer.files).filter((file) =>
        file.type.startsWith('image/')
      );
      if (filesArray.length > 0) {
        onFilesSelected(filesArray);
      }
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const filesArray = Array.from(e.target.files).filter((file) =>
        file.type.startsWith('image/')
      );
      if (filesArray.length > 0) {
        onFilesSelected(filesArray);
      }
      e.target.value = '';
    }
  };

  const handleLoadSample = async (type: 'jpeg' | 'png') => {
    try {
      setIsLoadingSample(true);
      const file = type === 'jpeg' ? await createSampleJpeg() : await createSamplePng();
      onFilesSelected([file]);
    } catch (err) {
      console.error('Failed to generate sample image:', err);
    } finally {
      setIsLoadingSample(false);
    }
  };

  return (
    <div className="w-full">
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="image/jpeg,image/png,image/webp,image/jpg"
        className="hidden"
        onChange={handleFileInputChange}
      />

      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`relative border-2 border-dashed rounded-2xl p-8 sm:p-12 text-center transition-all cursor-pointer select-none group ${
          isDragOver
            ? 'border-cyan-400 bg-cyan-500/10 scale-[1.005]'
            : 'border-slate-800 bg-slate-900/40 hover:border-slate-700 hover:bg-slate-900/60'
        }`}
      >
        <div className="flex flex-col items-center justify-center max-w-md mx-auto">
          {/* Main Icon */}
          <div
            className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-4 transition-transform group-hover:scale-105 ${
              isDragOver
                ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/30'
                : 'bg-slate-800 text-cyan-400 border border-slate-700'
            }`}
          >
            <UploadCloud className="w-8 h-8" />
          </div>

          <h2 className="text-lg sm:text-xl font-semibold text-white tracking-tight">
            Drop your JPEG or PNG images here
          </h2>

          <p className="text-sm text-slate-400 mt-1.5 leading-relaxed">
            Drag & drop files or click to browse. You can also press{' '}
            <kbd className="px-1.5 py-0.5 text-xs font-mono bg-slate-800 border border-slate-700 text-slate-300 rounded">
              Ctrl+V
            </kbd>{' '}
            or{' '}
            <kbd className="px-1.5 py-0.5 text-xs font-mono bg-slate-800 border border-slate-700 text-slate-300 rounded">
              ⌘V
            </kbd>{' '}
            to paste from clipboard.
          </p>

          <div className="flex items-center gap-3 mt-4 text-xs text-slate-500 font-medium">
            <span>Supports JPEG, JPG, PNG, WebP</span>
            <span aria-hidden="true">·</span>
            <span>Batch Upload</span>
            <span aria-hidden="true">·</span>
            <span>Up to 50MB each</span>
          </div>

          <button
            type="button"
            className="mt-6 px-5 py-2.5 text-xs font-semibold text-slate-950 bg-white hover:bg-slate-200 rounded-lg transition-colors shadow-sm"
          >
            Choose Images
          </button>
        </div>
      </div>

      {/* Quick Test Samples */}
      <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400 px-2">
        <div className="flex items-center gap-2">
          <span>Need a test image?</span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={isLoadingSample}
              onClick={() => handleLoadSample('jpeg')}
              className="text-cyan-400 hover:text-cyan-300 underline underline-offset-4 font-medium transition-colors cursor-pointer"
            >
              Load JPEG Sample
            </button>
            <span className="text-slate-600">/</span>
            <button
              type="button"
              disabled={isLoadingSample}
              onClick={() => handleLoadSample('png')}
              className="text-cyan-400 hover:text-cyan-300 underline underline-offset-4 font-medium transition-colors cursor-pointer"
            >
              Load PNG Sample (Transparent)
            </button>
          </div>
        </div>

        <div className="flex items-center gap-1.5 text-slate-500">
          <FileCheck2 className="w-3.5 h-3.5 text-emerald-400" />
          <span>100% Client-side · Private & Secure</span>
        </div>
      </div>
    </div>
  );
};
