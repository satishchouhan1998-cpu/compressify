import React, { useState } from 'react';
import {
  Download,
  Eye,
  Sliders,
  Trash2,
  CheckCircle2,
  Loader2,
  AlertCircle,
  ArrowRight,
  Maximize2,
} from 'lucide-react';
import { ImageFileItem, GlobalSettings } from '../types/compressor';
import { formatBytes, downloadFile, getOutputFilename } from '../utils/compressor';

interface ImageCardProps {
  item: ImageFileItem;
  globalSettings: GlobalSettings;
  onRemove: (id: string) => void;
  onOpenCompare: (item: ImageFileItem) => void;
  onTuneItem: (id: string, customSettings: Partial<GlobalSettings>) => void;
}

export const ImageCard: React.FC<ImageCardProps> = ({
  item,
  globalSettings,
  onRemove,
  onOpenCompare,
  onTuneItem,
}) => {
  const [showTuning, setShowTuning] = useState(false);

  const effectiveJpegQuality =
    item.customSettings?.jpegQuality !== undefined
      ? item.customSettings.jpegQuality
      : globalSettings.jpegQuality;

  const effectivePngColors =
    item.customSettings?.pngColors !== undefined
      ? item.customSettings.pngColors
      : globalSettings.pngColors;

  const isPng = item.originalFormat === 'image/png';

  const handleDownload = () => {
    if (item.compressedBlob) {
      const filename = getOutputFilename(item.name, item.compressedFormat);
      downloadFile(item.compressedBlob, filename);
    }
  };

  const getFormatName = (mime: string) => {
    if (mime === 'image/jpeg') return 'JPEG';
    if (mime === 'image/png') return 'PNG';
    if (mime === 'image/webp') return 'WebP';
    return mime;
  };

  return (
    <div className="border border-slate-800 bg-slate-900/60 rounded-xl p-4 transition-all hover:border-slate-700">
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
        {/* Thumbnail with compare trigger */}
        <div
          onClick={() => item.status === 'done' && onOpenCompare(item)}
          className={`relative w-16 h-16 sm:w-20 sm:h-20 rounded-lg overflow-hidden bg-slate-950 border border-slate-800 shrink-0 group ${
            item.status === 'done' ? 'cursor-pointer' : ''
          }`}
          title="Click to view interactive comparison"
        >
          <img
            src={item.compressedUrl || item.originalUrl}
            alt={item.name}
            className="w-full h-full object-cover transition-transform group-hover:scale-105"
          />
          {item.status === 'done' && (
            <div className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity text-white text-xs font-medium gap-1">
              <Eye className="w-4 h-4 text-cyan-400" />
            </div>
          )}
        </div>

        {/* Info Column */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold text-white truncate max-w-xs sm:max-w-md">
              {item.name}
            </h3>
            <span className="text-[11px] font-mono text-slate-400 border border-slate-800 bg-slate-950 px-1.5 py-0.5 rounded shrink-0">
              {getFormatName(item.originalFormat)}
            </span>
          </div>

          {/* Size Comparison Row */}
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1.5 text-xs text-slate-400">
            <div className="flex items-center gap-1.5 font-mono tabular-nums">
              <span>{formatBytes(item.originalSize)}</span>
              <span className="text-slate-600">({item.originalWidth}×{item.originalHeight})</span>
            </div>

            {item.status === 'done' && (
              <>
                <ArrowRight className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                <div className="flex items-center gap-1.5 font-mono tabular-nums">
                  <span className="text-cyan-400 font-semibold">{formatBytes(item.compressedSize)}</span>
                  <span className="text-slate-600">({item.compressedWidth}×{item.compressedHeight})</span>
                </div>
              </>
            )}
          </div>

          {/* Savings & Status Pill or Info */}
          <div className="mt-2 flex items-center gap-3 text-xs">
            {item.status === 'compressing' && (
              <span className="flex items-center gap-1.5 text-cyan-400">
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Compressing...</span>
              </span>
            )}

            {item.status === 'done' && (
              <div className="flex items-center gap-2">
                <span
                  className={`font-mono font-semibold tabular-nums ${
                    item.savingsPercent >= 0 ? 'text-emerald-400' : 'text-amber-400'
                  }`}
                >
                  {item.savingsPercent >= 0
                    ? `-${Math.round(item.savingsPercent)}% saved (${formatBytes(item.savingsBytes)})`
                    : `+${Math.abs(Math.round(item.savingsPercent))}% larger`}
                </span>
                <span className="text-slate-600">·</span>
                <span className="text-slate-500 font-mono text-[11px]">
                  Output: {getFormatName(item.compressedFormat)}
                </span>
              </div>
            )}

            {item.status === 'error' && (
              <span className="flex items-center gap-1.5 text-rose-400">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>{item.errorMessage || 'Compression failed'}</span>
              </span>
            )}
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
          {item.status === 'done' && (
            <>
              <button
                type="button"
                onClick={() => onOpenCompare(item)}
                className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
                title="Interactive Before / After slider"
              >
                <Eye className="w-3.5 h-3.5 text-cyan-400" />
                <span className="hidden md:inline">Compare</span>
              </button>

              <button
                type="button"
                onClick={() => setShowTuning(!showTuning)}
                className={`p-1.5 text-xs rounded-lg transition-colors cursor-pointer ${
                  showTuning
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
                title="Override settings for this image"
              >
                <Sliders className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={handleDownload}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors shadow-sm cursor-pointer"
                title="Download this compressed image"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download</span>
              </button>
            </>
          )}

          <button
            type="button"
            onClick={() => onRemove(item.id)}
            className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            title="Remove from queue"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Expandable Per-Image Tuning Drawer */}
      {showTuning && (
        <div className="mt-4 pt-3 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs bg-slate-950/40 p-3 rounded-lg">
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="font-medium text-slate-300">
                {isPng ? 'PNG Color Palette' : 'JPEG Quality'}
              </span>
              <span className="font-mono text-cyan-400 font-semibold">
                {isPng ? `${effectivePngColors} colors` : `${effectiveJpegQuality}%`}
              </span>
            </div>

            {!isPng ? (
              <input
                type="range"
                min="5"
                max="100"
                step="1"
                value={effectiveJpegQuality}
                onChange={(e) =>
                  onTuneItem(item.id, { jpegQuality: Number(e.target.value) })
                }
                className="w-full h-1 bg-slate-800 rounded appearance-none cursor-pointer accent-cyan-400"
              />
            ) : (
              <select
                value={effectivePngColors}
                onChange={(e) =>
                  onTuneItem(item.id, { pngColors: Number(e.target.value) })
                }
                className="w-full px-2 py-1 text-xs bg-slate-900 border border-slate-800 rounded text-slate-200"
              >
                <option value="16">16 Colors (Maximum compression)</option>
                <option value="32">32 Colors</option>
                <option value="64">64 Colors</option>
                <option value="128">128 Colors</option>
                <option value="256">256 Colors</option>
              </select>
            )}
          </div>

          <div className="flex items-center justify-between sm:justify-end gap-3 self-center">
            <span className="text-[11px] text-slate-500">
              Overrides global preset for this file
            </span>
            <button
              type="button"
              onClick={() => {
                onTuneItem(item.id, {
                  jpegQuality: globalSettings.jpegQuality,
                  pngColors: globalSettings.pngColors,
                });
              }}
              className="text-[11px] text-slate-400 hover:text-white underline cursor-pointer"
            >
              Reset to Global
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
