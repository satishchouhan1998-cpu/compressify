import React from 'react';
import { ShieldCheck, Cpu, Image as ImageIcon, Zap, Layers } from 'lucide-react';

export const TechPrivacySection: React.FC = () => {
  return (
    <section id="privacy" className="pt-8 border-t border-slate-800/80">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Card 1: 100% Client-Side Privacy */}
        <div className="border border-slate-800 bg-slate-900/40 rounded-xl p-5">
          <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mb-3">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-semibold text-white">100% Browser Execution</h3>
          <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
            Every image is processed directly inside your browser’s canvas engine using memory buffers.
            Zero bytes are transmitted to any remote cloud or server.
          </p>
        </div>

        {/* Card 2: JPEG DCT Optimization */}
        <div className="border border-slate-800 bg-slate-900/40 rounded-xl p-5">
          <div className="w-9 h-9 rounded-lg bg-sky-500/10 border border-sky-500/20 text-sky-400 flex items-center justify-center mb-3">
            <Cpu className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-semibold text-white">JPEG Quantization Tables</h3>
          <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
            Optimizes high-frequency chroma and luma Discrete Cosine Transform coefficients to
            eliminate imperceptible sensor noise while preserving crisp edge contrasts.
          </p>
        </div>

        {/* Card 3: PNG Color Quantization */}
        <div className="border border-slate-800 bg-slate-900/40 rounded-xl p-5">
          <div className="w-9 h-9 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center mb-3">
            <Layers className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-semibold text-white">PNG Palette & Dithering</h3>
          <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
            Standard PNGs are lossless. We apply median-cut color clustering and Floyd-Steinberg
            error diffusion to shrink 24-bit files down to 16–256 indexed colors with zero alpha loss.
          </p>
        </div>
      </div>

      {/* Format Comparison Table */}
      <div className="mt-8 border border-slate-800 bg-slate-900/40 rounded-xl p-5">
        <h3 className="text-sm font-semibold text-white mb-1">
          When to Choose JPEG vs. PNG
        </h3>
        <p className="text-xs text-slate-400 mb-4">
          Recommended guidelines for web performance, asset delivery, and quality retention.
        </p>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="pb-2 font-medium">Format</th>
                <th className="pb-2 font-medium">Best For</th>
                <th className="pb-2 font-medium">Alpha / Transparency</th>
                <th className="pb-2 font-medium">Compression Mechanism</th>
                <th className="pb-2 font-medium text-right">Typical Savings</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              <tr>
                <td className="py-2.5 font-semibold text-sky-400">JPEG (.jpg)</td>
                <td className="py-2.5 text-slate-400">Photographs, realistic portraits, landscapes</td>
                <td className="py-2.5 text-slate-500">No (Opaque)</td>
                <td className="py-2.5 text-slate-400">Lossy DCT frequency quantization</td>
                <td className="py-2.5 font-mono text-emerald-400 font-semibold text-right tabular-nums">
                  60% – 85%
                </td>
              </tr>
              <tr>
                <td className="py-2.5 font-semibold text-cyan-400">PNG (.png)</td>
                <td className="py-2.5 text-slate-400">Icons, logos, UI illustrations, screenshots</td>
                <td className="py-2.5 text-emerald-400 font-medium">Yes (8-bit / 24-bit Alpha)</td>
                <td className="py-2.5 text-slate-400">Median-cut palette + DEFLATE</td>
                <td className="py-2.5 font-mono text-emerald-400 font-semibold text-right tabular-nums">
                  40% – 75%
                </td>
              </tr>
              <tr>
                <td className="py-2.5 font-semibold text-purple-400">WebP (.webp)</td>
                <td className="py-2.5 text-slate-400">Modern web builds requiring high compression</td>
                <td className="py-2.5 text-emerald-400 font-medium">Yes (Lossy + Lossless)</td>
                <td className="py-2.5 text-slate-400">VP8 intra-frame block predictive encoding</td>
                <td className="py-2.5 font-mono text-emerald-400 font-semibold text-right tabular-nums">
                  70% – 90%
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};
