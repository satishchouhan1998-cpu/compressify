import React from 'react';
import { Download, Sparkles, Trash2, Upload } from 'lucide-react';
import { ImageFileItem } from '../types/compressor';

interface HeaderProps {
  items: ImageFileItem[];
  onOpenUpload: () => void;
  onClearAll: () => void;
  onDownloadAll: () => void;
  isZipping: boolean;
  zipProgress: number;
}

export const Header: React.FC<HeaderProps> = ({
  items,
  onOpenUpload,
  onClearAll,
  onDownloadAll,
  isZipping,
  zipProgress,
}) => {
  const completedCount = items.filter((i) => i.status === 'done' && i.compressedBlob).length;

  return (
    <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Zone 1: Single text element wordmark */}
        <a href="/" className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
          <span className="w-7 h-7 rounded-lg bg-gradient-to-tr from-cyan-400 to-blue-600 flex items-center justify-center text-xs font-black text-slate-950 shadow-sm">
            CF
          </span>
          <span>Compressify</span>
        </a>

        {/* Zone 2: Clean navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-400">
          <a href="#compressor" className="hover:text-slate-100 transition-colors">
            Compressor
          </a>
          <a href="#presets" className="hover:text-slate-100 transition-colors">
            Settings & Presets
          </a>
          <a href="#queue" className="hover:text-slate-100 transition-colors">
            Batch Queue {items.length > 0 && `(${items.length})`}
          </a>
          <a href="#privacy" className="hover:text-slate-100 transition-colors">
            Privacy & Engine
          </a>
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-3">
          {items.length > 0 && (
            <button
              onClick={onClearAll}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-400 hover:text-rose-400 hover:bg-slate-900 border border-slate-800 rounded-lg transition-colors whitespace-nowrap"
              title="Clear all images"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Queue</span>
            </button>
          )}

          {completedCount > 0 ? (
            <button
              onClick={onDownloadAll}
              disabled={isZipping}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-950 bg-gradient-to-r from-cyan-400 to-sky-400 hover:from-cyan-300 hover:to-sky-300 rounded-lg transition-all shadow-sm shadow-cyan-500/10 active:scale-95 disabled:opacity-50 whitespace-nowrap cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>
                {isZipping
                  ? `Zipping... ${Math.round(zipProgress)}%`
                  : `Download All ZIP (${completedCount})`}
              </span>
            </button>
          ) : (
            <button
              onClick={onOpenUpload}
              className="flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Add Images</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
