import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  X,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Download,
  RotateCcw,
  Sliders,
  Check,
  Split,
  Columns,
} from 'lucide-react';
import { ImageFileItem, GlobalSettings, ImageFormat } from '../types/compressor';
import { compressImage, formatBytes, downloadFile, getOutputFilename } from '../utils/compressor';

interface CompareModalProps {
  item: ImageFileItem;
  globalSettings: GlobalSettings;
  onClose: () => void;
  onUpdateItem: (updated: ImageFileItem) => void;
}

export const CompareModal: React.FC<CompareModalProps> = ({
  item,
  globalSettings,
  onClose,
  onUpdateItem,
}) => {
  const [sliderPosition, setSliderPosition] = useState(50); // percentage 0 - 100
  const [isDragging, setIsDragging] = useState(false);
  const [zoom, setZoom] = useState(1); // 1 = fit, 2 = 200%, etc.
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState({ x: 0, y: 0 });
  const [viewMode, setViewMode] = useState<'split' | 'side-by-side'>('split');

  // Local quality override for interactive testing
  const [localQuality, setLocalQuality] = useState<number>(() => {
    if (item.customSettings?.jpegQuality !== undefined) return item.customSettings.jpegQuality;
    return globalSettings.jpegQuality;
  });

  const [localColors, setLocalColors] = useState<number>(() => {
    if (item.customSettings?.pngColors !== undefined) return item.customSettings.pngColors;
    return globalSettings.pngColors;
  });

  const [isRecompressing, setIsRecompressing] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  // Handle curtain divider dragging
  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleMouseMove = useCallback(
    (e: MouseEvent) => {
      if (isDragging && containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        const clientX = e.clientX;
        const offset = clientX - rect.left;
        const percentage = Math.max(0, Math.min(100, (offset / rect.width) * 100));
        setSliderPosition(percentage);
      } else if (isPanning) {
        setPan({
          x: e.clientX - panStart.x,
          y: e.clientY - panStart.y,
        });
      }
    },
    [isDragging, isPanning, panStart]
  );

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
    setIsPanning(false);
  }, []);

  useEffect(() => {
    if (isDragging || isPanning) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, isPanning, handleMouseMove, handleMouseUp]);

  // Touch support for split slider
  const handleTouchMove = (e: React.TouchEvent) => {
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      const touchX = e.touches[0].clientX;
      const offset = touchX - rect.left;
      const percentage = Math.max(0, Math.min(100, (offset / rect.width) * 100));
      setSliderPosition(percentage);
    }
  };

  // Recompress when local slider changes
  const handleApplyLocalQuality = async (newQuality: number, newColors: number) => {
    setIsRecompressing(true);
    try {
      const effectiveSettings: GlobalSettings = {
        ...globalSettings,
        ...(item.customSettings || {}),
        jpegQuality: newQuality,
        pngColors: newColors,
      };

      const result = await compressImage(item, effectiveSettings);
      const updatedItem: ImageFileItem = {
        ...item,
        customSettings: {
          ...(item.customSettings || {}),
          jpegQuality: newQuality,
          pngColors: newColors,
        },
        compressedBlob: result.blob,
        compressedUrl: result.url,
        compressedSize: result.size,
        compressedWidth: result.width,
        compressedHeight: result.height,
        compressedFormat: result.format,
        savingsBytes: result.savingsBytes,
        savingsPercent: result.savingsPercent,
        status: 'done',
      };
      onUpdateItem(updatedItem);
    } catch (err) {
      console.error('Recompression error in modal:', err);
    } finally {
      setIsRecompressing(false);
    }
  };

  const handleDownload = () => {
    if (item.compressedBlob) {
      const filename = getOutputFilename(item.name, item.compressedFormat);
      downloadFile(item.compressedBlob, filename);
    }
  };

  const isPng = item.originalFormat === 'image/png';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md">
      <div className="w-full max-w-6xl h-[92vh] flex flex-col bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Top Header */}
        <div className="px-5 py-3.5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <h2 className="text-sm font-semibold text-white truncate max-w-sm sm:max-w-md">
              {item.name}
            </h2>
            <div className="hidden sm:flex items-center gap-2 text-xs font-mono tabular-nums text-slate-400">
              <span>{formatBytes(item.originalSize)}</span>
              <span>→</span>
              <span className="text-cyan-400 font-semibold">{formatBytes(item.compressedSize)}</span>
              <span className="text-emerald-400 font-semibold">
                ({item.savingsPercent >= 0 ? `-${Math.round(item.savingsPercent)}%` : `+${Math.abs(Math.round(item.savingsPercent))}%`})
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* View Mode Toggle */}
            <div className="flex items-center p-0.5 bg-slate-800 border border-slate-700 rounded-lg">
              <button
                type="button"
                onClick={() => setViewMode('split')}
                title="Curtain Split Slider"
                className={`p-1.5 rounded text-xs transition-colors cursor-pointer ${
                  viewMode === 'split' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Split className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setViewMode('side-by-side')}
                title="Side by Side"
                className={`p-1.5 rounded text-xs transition-colors cursor-pointer ${
                  viewMode === 'side-by-side'
                    ? 'bg-slate-700 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Columns className="w-4 h-4" />
              </button>
            </div>

            {/* Zoom Controls */}
            <div className="hidden md:flex items-center gap-1 bg-slate-800 border border-slate-700 rounded-lg px-1.5 py-0.5 text-xs text-slate-300">
              <button
                type="button"
                onClick={() => {
                  setZoom((prev) => Math.max(0.5, prev - 0.25));
                }}
                className="p-1 hover:text-white cursor-pointer"
                title="Zoom Out"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <span className="font-mono tabular-nums w-12 text-center">
                {Math.round(zoom * 100)}%
              </span>
              <button
                type="button"
                onClick={() => {
                  setZoom((prev) => Math.min(4, prev + 0.25));
                }}
                className="p-1 hover:text-white cursor-pointer"
                title="Zoom In"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => {
                  setZoom(1);
                  setPan({ x: 0, y: 0 });
                }}
                className="p-1 hover:text-white border-l border-slate-700 ml-1 cursor-pointer"
                title="Reset Zoom"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>

            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Download</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              title="Close modal (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Interactive Comparison Canvas Area */}
        <div className="flex-1 relative overflow-hidden bg-slate-950 select-none flex items-center justify-center">
          {/* Subtle checkered backdrop for transparent images */}
          <div
            className="absolute inset-0 opacity-15"
            style={{
              backgroundImage: `linear-gradient(45deg, #1e293b 25%, transparent 25%), linear-gradient(-45deg, #1e293b 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #1e293b 75%), linear-gradient(-45deg, transparent 75%, #1e293b 75%)`,
              backgroundSize: '20px 20px',
              backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px',
            }}
          />

          {viewMode === 'split' ? (
            <div
              ref={containerRef}
              onTouchMove={handleTouchMove}
              className="relative w-full h-full flex items-center justify-center overflow-hidden cursor-crosshair"
              style={{
                cursor: zoom > 1 ? (isPanning ? 'grabbing' : 'grab') : 'default',
              }}
              onMouseDown={(e) => {
                if (zoom > 1 && !isDragging) {
                  setIsPanning(true);
                  setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
                }
              }}
            >
              {/* Image transform wrapper */}
              <div
                className="relative max-w-full max-h-full transition-transform duration-75"
                style={{
                  transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
                  transformOrigin: 'center center',
                }}
              >
                {/* Layer 1: Compressed Image (Bottom Layer) */}
                {item.compressedUrl && (
                  <img
                    src={item.compressedUrl}
                    alt="Compressed Preview"
                    className="max-w-[85vw] max-h-[70vh] object-contain pointer-events-none block"
                    draggable={false}
                  />
                )}

                {/* Layer 2: Original Image (Top Layer clipped by slider) */}
                <div
                  className="absolute inset-0 overflow-hidden pointer-events-none"
                  style={{
                    clipPath: `polygon(0 0, ${sliderPosition}% 0, ${sliderPosition}% 100%, 0 100%)`,
                  }}
                >
                  <img
                    src={item.originalUrl}
                    alt="Original Preview"
                    className="max-w-[85vw] max-h-[70vh] object-contain block"
                    draggable={false}
                  />
                </div>

                {/* Divider Line */}
                <div
                  className="absolute top-0 bottom-0 pointer-events-auto cursor-ew-resize z-20"
                  style={{ left: `${sliderPosition}%`, transform: 'translateX(-50%)' }}
                  onMouseDown={handleMouseDown}
                >
                  <div className="w-0.5 h-full bg-cyan-400 shadow-[0_0_8px_rgba(6,182,212,0.8)]" />
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-cyan-400 text-slate-950 flex items-center justify-center shadow-lg border-2 border-white select-none active:scale-95 transition-transform">
                    <Split className="w-4 h-4 rotate-90" />
                  </div>
                </div>
              </div>

              {/* Labels on sides */}
              <div className="absolute top-4 left-4 z-30 pointer-events-none">
                <span className="px-2.5 py-1 text-xs font-semibold bg-slate-900/90 text-slate-200 border border-slate-700 rounded-md backdrop-blur-sm shadow-md">
                  Original ({formatBytes(item.originalSize)})
                </span>
              </div>
              <div className="absolute top-4 right-4 z-30 pointer-events-none">
                <span className="px-2.5 py-1 text-xs font-semibold bg-cyan-950/90 text-cyan-300 border border-cyan-800 rounded-md backdrop-blur-sm shadow-md">
                  Compressed ({formatBytes(item.compressedSize)})
                </span>
              </div>
            </div>
          ) : (
            /* Side by Side View */
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full h-full p-4 overflow-auto">
              <div className="flex flex-col items-center justify-center border border-slate-800 rounded-xl p-3 bg-slate-900/40 relative">
                <div className="absolute top-3 left-3 px-2 py-0.5 text-xs font-semibold bg-slate-800 text-slate-300 rounded">
                  Original · {formatBytes(item.originalSize)} ({item.originalWidth}×{item.originalHeight})
                </div>
                <img
                  src={item.originalUrl}
                  alt="Original"
                  className="max-h-[60vh] object-contain rounded"
                />
              </div>

              <div className="flex flex-col items-center justify-center border border-slate-800 rounded-xl p-3 bg-slate-900/40 relative">
                <div className="absolute top-3 left-3 px-2 py-0.5 text-xs font-semibold bg-cyan-950 text-cyan-300 border border-cyan-800 rounded">
                  Compressed · {formatBytes(item.compressedSize)} ({item.compressedWidth}×{item.compressedHeight})
                </div>
                {item.compressedUrl && (
                  <img
                    src={item.compressedUrl}
                    alt="Compressed"
                    className="max-h-[60vh] object-contain rounded"
                  />
                )}
              </div>
            </div>
          )}
        </div>

        {/* Bottom Tuning Bar: Live Interactive Quality Adjustment */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-semibold text-slate-200">
              Live Tuning ({isPng ? 'PNG Palette' : 'JPEG Quality'}):
            </span>
          </div>

          <div className="flex-1 max-w-xl flex items-center gap-4">
            {!isPng ? (
              <div className="w-full flex items-center gap-3">
                <input
                  type="range"
                  min="5"
                  max="100"
                  step="1"
                  value={localQuality}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setLocalQuality(val);
                    handleApplyLocalQuality(val, localColors);
                  }}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                />
                <span className="text-xs font-mono font-bold tabular-nums text-cyan-400 w-12 text-right">
                  {localQuality}%
                </span>
              </div>
            ) : (
              <div className="w-full flex items-center gap-3">
                <select
                  value={localColors}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setLocalColors(val);
                    handleApplyLocalQuality(localQuality, val);
                  }}
                  className="w-full px-3 py-1.5 text-xs bg-slate-900 border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-cyan-500"
                >
                  <option value="16">16 Colors (Maximum compression)</option>
                  <option value="32">32 Colors (Aggressive compression)</option>
                  <option value="64">64 Colors (Solid compression)</option>
                  <option value="128">128 Colors (High fidelity)</option>
                  <option value="256">256 Colors (Crisp)</option>
                </select>
                <span className="text-xs font-mono font-bold tabular-nums text-cyan-400 w-24 text-right">
                  {localColors} cols
                </span>
              </div>
            )}
          </div>

          <div className="flex items-center justify-end text-xs text-slate-400">
            {isRecompressing ? (
              <span className="text-cyan-400 animate-pulse">Rendering preview...</span>
            ) : (
              <span className="flex items-center gap-1 text-emerald-400">
                <Check className="w-3.5 h-3.5" />
                <span>Live Preview Active</span>
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
