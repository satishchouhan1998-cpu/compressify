import React from 'react';
import { formatBytes } from '../utils/compressor';
import { ImageFileItem } from '../types/compressor';

interface StatsSummaryProps {
  items: ImageFileItem[];
}

export const StatsSummary: React.FC<StatsSummaryProps> = ({ items }) => {
  const completed = items.filter((i) => i.status === 'done');
  if (completed.length === 0) return null;

  const totalOriginal = completed.reduce((sum, i) => sum + i.originalSize, 0);
  const totalCompressed = completed.reduce((sum, i) => sum + i.compressedSize, 0);
  const totalSaved = totalOriginal - totalCompressed;
  const overallPercentage = totalOriginal > 0 ? (totalSaved / totalOriginal) * 100 : 0;

  return (
    <div className="border border-slate-800 bg-slate-900/60 rounded-xl p-4 sm:p-5 backdrop-blur-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-sm font-semibold text-slate-200">Compression Summary</h3>
          <p className="text-xs text-slate-400 mt-0.5">
            {completed.length} of {items.length} {items.length === 1 ? 'image' : 'images'} optimized
          </p>
        </div>

        {/* Clean unboxed tabular stats */}
        <div className="grid grid-cols-3 gap-6 sm:gap-8 text-left sm:text-right">
          <div>
            <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">
              Original
            </div>
            <div className="text-sm sm:text-base font-semibold font-mono tabular-nums text-slate-300 mt-0.5">
              {formatBytes(totalOriginal)}
            </div>
          </div>

          <div>
            <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">
              Compressed
            </div>
            <div className="text-sm sm:text-base font-semibold font-mono tabular-nums text-cyan-400 mt-0.5">
              {formatBytes(totalCompressed)}
            </div>
          </div>

          <div>
            <div className="text-[11px] font-medium text-emerald-400 uppercase tracking-wider">
              Saved
            </div>
            <div className="text-sm sm:text-base font-bold font-mono tabular-nums text-emerald-400 mt-0.5 flex items-center sm:justify-end gap-1">
              <span>{overallPercentage >= 0 ? `-${Math.round(overallPercentage)}%` : `+${Math.abs(Math.round(overallPercentage))}%`}</span>
              <span className="text-xs font-normal text-slate-400">({formatBytes(Math.abs(totalSaved))})</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
